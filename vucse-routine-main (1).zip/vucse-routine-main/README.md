# vucse-routine
This repository is for fetching data from google sheet(MS Excel format) to JavaScript.
